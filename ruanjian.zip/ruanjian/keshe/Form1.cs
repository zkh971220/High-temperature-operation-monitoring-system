﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using Microsoft.Win32;

namespace keshe
{
    public partial class Form1 : Form
    {
        int temp,warntemp;
        String stemp,speople;
        bool mark=false;
        public Form1()
        {
            InitializeComponent();
            Control.CheckForIllegalCrossThreadCalls = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            RegistryKey keyCom = Registry.LocalMachine.OpenSubKey("Hardware\\DeviceMap\\SerialComm");
            if (keyCom != null)
            {
                string[] sSubKeys = keyCom.GetValueNames();
                cmbPort1.Items.Clear();
                foreach (string sName in sSubKeys)
                {
                    string sValue = (string)keyCom.GetValue(sName);
                    cmbPort1.Items.Add(sValue);
                }
                if (cmbPort1.Items.Count > 0)
                    cmbPort1.SelectedIndex = 0;
                cmbBaud1.Text = "115200";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (mark == false)
            {
                serialPort1.PortName = cmbPort1.Text;
                serialPort1.BaudRate = Convert.ToInt32(cmbBaud1.Text);
                serialPort1.Open();
                button1.Text = "关闭监控";
                if (serialPort1.IsOpen == true)
                {
                    label6.Text = "监控中...";
                }
                else
                {
                    label6.Text = "";
                }
                
                label6.BackColor = Color.Transparent;
                mark = true;
            }
            else
            {
                serialPort1.Close();
                button1.Text = "开始监控";
                textBox1.Clear();
                textBox2.Clear();
                textBox2.BackColor = Color.White;
                label6.Text = "";
                label6.BackColor = Color.Transparent;
                mark = false;
            }
        }
        private void serialPort2_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            /*
            string  receive= serialPort2.ReadExisting();
            byte[] a=Encoding.UTF8.GetBytes(receive.Trim());
            for(int i=0;i<a.Length;i++)
            {
                textBox2.Text+= a[i].ToString();
            }
            */
            int count = serialPort1.BytesToRead;
            byte[] receive = new byte[count];
            serialPort1.Read(receive, 0, count);
            stemp = System.Text.Encoding.Default.GetString(receive).Substring(0, 2);
            speople = System.Text.Encoding.Default.GetString(receive).Substring(2, 1);
            warntemp = Convert.ToInt32(textBox3.Text);
            if (stemp == "")
            { }
            else
            {
                textBox2.Text = stemp;
                temp = Convert.ToInt32(textBox2.Text);
            }
            if (speople=="1")
            {
                textBox1.Text = "有人工作";
                if (temp >= warntemp)
                {
                    textBox2.BackColor = Color.Red;
                    label6.Text = "温度超标！";
                    label6.BackColor = Color.Red;
                }
                else
                {
                    textBox2.BackColor = Color.White;
                    label6.Text = "监控中...";
                    label6.BackColor = Color.Transparent;
                }
            }
            else
            {
                textBox1.Text = "无人工作";
                textBox2.BackColor = Color.White;
                label6.Text = "监控中...";
                label6.BackColor = Color.Transparent;
            }
        }
    }
}
